import torch
import torch.nn as nn
import numpy as np

net = nn.Sequential(nn.Linear(2, 16), nn.ReLU(), nn.Linear(16, 1), nn.Sigmoid())
opt = torch.optim.SGD(net.parameters(), lr=0.05)

def get_moves(s, player):
    moves = []
    for dice in [1, 2, 3]:
        if player == 0:
            moves.append([min(10, s[0] + dice), s[1]])
        else:
            moves.append([s[0], min(10, s[1] + dice)])
    return moves

def pick_move(s, ply):
    moves = get_moves(s, player=0)
    if ply == 1:
        V = []
        for m in moves:
            score = net(torch.FloatTensor(m)).item()
            V.append(score)
        best_idx = np.argmax(V)
        return moves[best_idx]
    else:
        V = []
        for m in moves:
            opp_moves = get_moves(m, player=1)
            opp_scores = []
            for opp in opp_moves:
                score = net(torch.FloatTensor(opp)).item()
                opp_scores.append(score)
            worst_case = min(opp_scores)
            V.append(worst_case)
        best_idx = np.argmax(V)
        return moves[best_idx]

for ep in range(500):
    s = [0, 0]
    while s[0] < 10 and s[1] < 10:
        next_s = pick_move(s, ply=1)
        if next_s[1] < 10:
            opp_options = get_moves(next_s, player=1)
            next_s = opp_options[np.random.randint(3)]

        done = (next_s[0] >= 10) or (next_s[1] >= 10)
        if done:
            target = 1.0 if next_s[0] >= 10 else 0.0
        else:
            target = net(torch.FloatTensor(next_s)).item()

        loss = (net(torch.FloatTensor(s)) - target) ** 2
        opt.zero_grad()
        loss.backward()
        opt.step()
        s = next_s

print("1-Ply Move from [5, 5]:", pick_move([5, 5], ply=1))
print("2-Ply Move from [5, 5]:", pick_move([5, 5], ply=2))