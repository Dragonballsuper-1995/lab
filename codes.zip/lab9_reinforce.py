import gymnasium as gym
import torch
import torch.nn as nn

env = gym.make("CartPole-v1")
actor = nn.Sequential(nn.Linear(4, 32), nn.ReLU(), nn.Linear(32, 2), nn.Softmax(dim=-1))
critic = nn.Sequential(nn.Linear(4, 32), nn.ReLU(), nn.Linear(32, 1))
opt = torch.optim.Adam(list(actor.parameters()) + list(critic.parameters()), lr=1e-3)
gamma = 0.99

for ep in range(1, 301):
    s, _ = env.reset()
    done = False
    total_r = 0.0

    while not done:
        s_t = torch.FloatTensor(s)
        dist = torch.distributions.Categorical(actor(s_t))
        a = dist.sample()

        next_s, r, term, trunc, _ = env.step(a.item())
        done = term or trunc

        v_s = critic(s_t)
        if done:
            v_next = 0.0
        else:
            v_next = critic(torch.FloatTensor(next_s)).item()

        td_target = r + gamma * v_next

        actor_loss = -dist.log_prob(a) * td_target
        critic_loss = (td_target - v_s) ** 2
        loss = actor_loss + critic_loss

        opt.zero_grad()
        loss.backward()
        opt.step()

        s = next_s
        total_r += r

    if ep % 50 == 0:
        print("REINFORCE Episode:", ep, "| Score:", total_r)