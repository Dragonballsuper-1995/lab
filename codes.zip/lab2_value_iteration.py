import numpy as np

states = []
for r in range(10):
    for c in range(10):
        states.append((r, c))

actions = [(-1, 0), (1, 0), (0, -1), (0, 1)]
names = ["Up", "Down", "Left", "Right"]

def step(s, a):
    nr = max(0, min(9, s[0] + actions[a][0]))
    nc = max(0, min(9, s[1] + actions[a][1]))
    done = (nr, nc) == (9, 9)
    r = 10.0 if done else -1.0
    return (nr, nc), r, done

def get_val(s, a, V, gamma):
    total = 0.0
    for actual_a in range(4):
        if actual_a == a:
            prob = 0.8
        else:
            prob = 0.2 / 3.0
        next_s, r, _ = step(s, actual_a)
        total += prob * (r + gamma * V[next_s])
    return total

def run_vi(gamma):
    V = {}
    policy = {}
    for s in states:
        V[s] = 0.0
        policy[s] = "GOAL"

    for _ in range(100):
        for s in states:
            if s == (9, 9):
                continue
            scores = []
            for a in range(4):
                scores.append(get_val(s, a, V, gamma))
            best_idx = np.argmax(scores)
            V[s] = scores[best_idx]
            policy[s] = names[best_idx]
    return V, policy

V_09, pol_09 = run_vi(0.9)
V_0, _ = run_vi(0.0)
V_1, _ = run_vi(1.0)

print("Gamma 0.9 -> V(0,0):", round(V_09[(0, 0)], 2), "| Best Action:", pol_09[(0, 0)])
print("Gamma 0.0 -> V(0,0):", round(V_0[(0, 0)], 2))
print("Gamma 1.0 -> V(0,0):", round(V_1[(0, 0)], 2))