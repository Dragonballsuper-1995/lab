import numpy as np

probs = [0.3, 0.5, 0.67]  # Secret click probabilities for Ad 0, Ad 1, Ad 2
T = 500
variants = ["Standard", "Linear", "Exponential", "Step", "Inverse"]

for variant in variants:
    Q = np.zeros(3)       # Estimated value of each ad
    N = np.zeros(3)       # Number of times each ad was chosen
    regret = 0.0

    for t in range(1, T + 1):
        # 1. Calculate epsilon for the current step
        if variant == "Standard":
            eps = 0.2
        elif variant == "Linear":
            eps = max(0.05, 1.0 - (0.95 / T) * t)
        elif variant == "Exponential":
            eps = 0.05 + 0.95 * np.exp(-0.01 * t)
        elif variant == "Step":
            eps = max(0.05, 1.0 * (0.8 ** (t // 100)))
        elif variant == "Inverse":
            eps = 1.0 / (1 + 0.01 * t)

        # 2. Pick action: Explore (random) or Exploit (best Q)
        if np.random.rand() < eps:
            a = np.random.randint(3)
        else:
            a = np.argmax(Q)

        # 3. Get reward (1 if clicked, 0 if not)
        if np.random.rand() < probs[a]:
            r = 1
        else:
            r = 0

        # 4. Update count, Q-value, and cumulative regret
        N[a] += 1
        Q[a] += (1.0 / N[a]) * (r - Q[a])
        regret += max(probs) - probs[a]

    print(variant, "| Final Regret:", round(regret, 2), "| Q:", np.round(Q, 2))