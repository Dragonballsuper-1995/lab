import gymnasium as gym
import torch
import torch.nn as nn

env = gym.make("CartPole-v1")
actor = nn.Sequential(nn.Linear(4, 32), nn.ReLU(), nn.Linear(32, 2), nn.Softmax(dim=-1))
critic = nn.Sequential(nn.Linear(4, 32), nn.ReLU(), nn.Linear(32, 1))
opt = torch.optim.Adam(list(actor.parameters()) + list(critic.parameters()), lr=1e-3)
gamma = 0.99

for ep in range(1, 301):
    s, _ = env.reset()
    done = False
    total_r = 0.0

    while not done:
        s_t = torch.FloatTensor(s)
        dist = torch.distributions.Categorical(actor(s_t))
        a = dist.sample()
        old_log_prob = dist.log_prob(a).item()

        next_s, r, term, trunc, _ = env.step(a.item())
        done = term or trunc

        if done:
            v_next = 0.0
        else:
            v_next = critic(torch.FloatTensor(next_s)).item()

        td_target = r + gamma * v_next
        advantage = td_target - critic(s_t).item()

        # PPO Clipped Update over 3 epochs
        for _ in range(3):
            new_dist = torch.distributions.Categorical(actor(s_t))
            ratio = torch.exp(new_dist.log_prob(a) - old_log_prob)

            surr1 = ratio * advantage
            surr2 = torch.clamp(ratio, 0.8, 1.2) * advantage
            actor_loss = -torch.min(surr1, surr2)

            v_s = critic(s_t)
            critic_loss = (td_target - v_s) ** 2
            loss = actor_loss + critic_loss

            opt.zero_grad()
            loss.backward()
            opt.step()

        s = next_s
        total_r += r

    if ep % 50 == 0:
        print("PPO Episode:", ep, "| Score:", total_r)