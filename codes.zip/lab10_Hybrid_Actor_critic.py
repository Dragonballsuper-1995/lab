import torch
import torch.nn as nn

TARGET = 8.0

def step(s, direction, speed):
    speed = max(0.5, min(3.0, speed))
    next_floor = max(0.0, min(10.0, s[0] + (direction - 1) * speed))
    reward = abs(s[0] - TARGET) - abs(next_floor - TARGET) - 0.05
    done = abs(next_floor - TARGET) < 0.5
    if done:
        reward += 10
    return [next_floor], reward, done

actor_dir = nn.Sequential(
    nn.Linear(1, 16), nn.ReLU(),
    nn.Linear(16, 3), nn.Softmax(dim=-1)
)
actor_speed = nn.Sequential(
    nn.Linear(1, 16), nn.ReLU(),
    nn.Linear(16, 1), nn.Sigmoid()
)
critic = nn.Sequential(
    nn.Linear(1, 16), nn.ReLU(),
    nn.Linear(16, 1)
)

optimizer = torch.optim.Adam(list(actor_dir.parameters()) + list(actor_speed.parameters()) + list(critic.parameters()), lr=0.001)
gamma = 0.95

for ep in range(1, 1001):
    s = [0.0]
    total_reward = 0

    for _ in range(30):
        st = torch.tensor(s, dtype=torch.float32)

        d_dist = torch.distributions.Categorical(actor_dir(st))
        speed_mean = 0.5 + 2.5 * actor_speed(st)
        sp_dist = torch.distributions.Normal(speed_mean, 0.5)

        d = d_dist.sample()
        speed = sp_dist.sample()

        ns, r, done = step(s, d.item(), speed.item())

        value = critic(st)
        next_value = 0.0 if done else critic(torch.tensor(ns, dtype=torch.float32)).item()

        target = r + gamma * next_value
        advantage = target - value.item()

        actor_loss = -(d_dist.log_prob(d) + sp_dist.log_prob(speed)) * advantage
        critic_loss = (target - value) ** 2

        loss = actor_loss + critic_loss

        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        s = ns
        total_reward += r

        if done:
            break

    if ep % 100 == 0:
        print("Episode:", ep, "| Reward:", round(total_reward, 1), "| Floor:", round(s[0], 1))