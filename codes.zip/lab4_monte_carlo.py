import numpy as np
from collections import defaultdict

def run_mc(step_fn, start_s, gamma, episodes):
    V = defaultdict(float)
    N = defaultdict(int)

    for _ in range(episodes):
        s = start_s
        ep_history = []
        done = False

        # 1. Play one episode
        while not done and len(ep_history) < 100:
            next_s, r, done = step_fn(s)
            ep_history.append((s, r))
            s = next_s

        # 2. Loop backward to compute return G
        G = 0.0
        visited = set()
        for s_step, r_step in reversed(ep_history):
            G = r_step + gamma * G
            if s_step not in visited:
                visited.add(s_step)
                N[s_step] += 1
                V[s_step] += (1.0 / N[s_step]) * (G - V[s_step])
    return V

# --- Part 1: 3-State MDP (Always Right) ---
def step_part1(s):
    if s == "S1":
        return "S2", 0.0, False
    elif s == "S2":
        return "S3", 1.0, True
    return "S3", 0.0, True

V1 = run_mc(step_part1, "S1", 0.9, 1000)
print("Part 1 Values:", dict(V1))

# --- Part 2: 4x4 Gridworld (Uniform Random Policy) ---
actions = [(-1, 0), (1, 0), (0, -1), (0, 1)]
def step_part2(s):
    a = np.random.randint(4)
    nr = s[0] + actions[a][0]
    nc = s[1] + actions[a][1]
    if not (0 <= nr < 4 and 0 <= nc < 4):
        return s, -1.0, False
    if (nr, nc) == (3, 3):
        return (3, 3), 10.0, True
    return (nr, nc), 0.0, False

V2 = run_mc(step_part2, (0, 0), 0.95, 10000)
print("\nPart 2 (4x4 Grid Values):")
for r in range(4):
    row_vals = []
    for c in range(4):
        row_vals.append(round(V2[(r, c)], 2))
    print(row_vals)