import numpy as np
from collections import defaultdict

actions = [(-1, 0), (1, 0), (0, -1), (0, 1)]
obstacles = {(3,8), (4,8), (5,8), (10,2), (10,3), (10,4), (10,5)}
chargers = {(4,4), (11,11)}
goals = [(0, 15), (15, 0), (15, 15), (7, 12)]

def step(s, a):
    r, c, b, stage = s
    if 6 <= r <= 9 and 6 <= c <= 9 and np.random.rand() < 0.25:
        a = 1  # Wind drifts drone Down

    nr = r + actions[a][0]
    nc = c + actions[a][1]
    b -= 1
    reward = -1.0

    if not (0 <= nr < 16 and 0 <= nc < 16) or (nr, nc) in obstacles:
        nr, nc = r, c
        reward -= 10.0

    if (nr, nc) in chargers and b < 40:
        b = 40
        reward += 5.0

    if (nr, nc) == goals[stage]:
        if stage == 1:
            reward += 100.0
        elif stage == 3:
            reward += 300.0
        stage += 1

    done = (stage == 4) or (b <= 0)
    if b <= 0 and stage < 4:
        reward -= 200.0

    return (nr, nc, b, stage), reward, done

Q = defaultdict(lambda: np.zeros(4))
alpha = 0.1
gamma = 0.99

for ep in range(1, 5001):
    s = (0, 0, 40, 0)
    done = False
    total_r = 0.0
    eps = max(0.01, 1.0 * np.exp(-0.0005 * ep))

    while not done:
        if np.random.rand() < eps:
            a = np.random.randint(4)
        else:
            a = np.argmax(Q[s])

        next_s, r, done = step(s, a)
        Q[s][a] += alpha * (r + gamma * np.max(Q[next_s]) - Q[s][a])
        s = next_s
        total_r += r

    if ep % 1000 == 0:
        print("Episode:", ep, "| Total Reward:", total_r, "| Stage:", s[3])