import numpy as np
from collections import defaultdict

def step(s, a):
    q_ns, q_ew = s
    arr_ns = np.random.poisson(1.2)
    arr_ew = np.random.poisson(1.0)

    clear_ns = 3 if a == 0 else 0
    clear_ew = 3 if a == 1 else 0

    next_ns = max(0, min(10, q_ns + arr_ns - clear_ns))
    next_ew = max(0, min(10, q_ew + arr_ew - clear_ew))
    reward = -(next_ns + next_ew)
    return (next_ns, next_ew), reward, False

Q = defaultdict(lambda: np.zeros(2))
alpha = 0.1
gamma = 0.95
eps = 0.1

for ep in range(1, 5001):
    s = (0, 0)
    if np.random.rand() < eps:
        a = np.random.randint(2)
    else:
        a = np.argmax(Q[s])

    total_wait = 0.0
    for _ in range(50):
        next_s, r, _ = step(s, a)
        if np.random.rand() < eps:
            next_a = np.random.randint(2)
        else:
            next_a = np.argmax(Q[next_s])

        # SARSA update uses actual next_a
        Q[s][a] += alpha * (r + gamma * Q[next_s][next_a] - Q[s][a])
        s = next_s
        a = next_a
        total_wait += -r

    if ep % 1000 == 0:
        print("Episode:", ep, "| Avg Waiting Cars:", round(total_wait / 50.0, 2))