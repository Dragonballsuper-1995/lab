import torch
import torch.nn as nn
import random

TARGET = 8

def step(s, a):
    change = (a - 1) + random.randint(-1, 1)
    next_s = max(0, min(10, s[0] + change))
    fuel_cost = 2 if a == 2 else 0
    reward = -abs(next_s - TARGET) - fuel_cost
    done = (next_s == TARGET)
    return [next_s], reward, done

def run_ac(mode):
    actor = nn.Sequential(nn.Linear(1, 32), nn.ReLU(), nn.Linear(32, 3), nn.Softmax(dim=-1))
    critic = nn.Sequential(nn.Linear(1, 32), nn.ReLU(), nn.Linear(32, 1))
    opt = torch.optim.Adam(list(actor.parameters()) + list(critic.parameters()), lr=1e-3)
    gamma = 0.95

    for ep in range(200):
        s = [2.0]
        total_r = 0.0

        for _ in range(30):
            s_t = torch.FloatTensor(s)
            dist = torch.distributions.Categorical(actor(s_t))
            a = dist.sample()

            next_s, r, done = step(s, a.item())

            v_s = critic(s_t)
            if done:
                v_next = 0.0
            else:
                v_next = critic(torch.FloatTensor(next_s)).item()

            td_target = r + gamma * v_next
            advantage = td_target - v_s.item()

            if mode == "Simple":
                actor_loss = -dist.log_prob(a) * td_target
            else:
                actor_loss = -dist.log_prob(a) * advantage

            critic_loss = (td_target - v_s) ** 2
            loss = actor_loss + critic_loss

            opt.zero_grad()
            loss.backward()
            opt.step()

            s = next_s
            total_r += r
            if done:
                break
    return total_r

print("Simple Actor-Critic Final Reward  :", run_ac("Simple"))
print("Advanced Actor-Critic Final Reward:", run_ac("Advanced"))