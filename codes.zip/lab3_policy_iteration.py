import numpy as np

zones = ["A", "B", "C", "D", "E", "F", "G"]
neighbors = {
    "A": ["B"], "B": ["A", "C"], "C": ["B", "D"],
    "D": ["C", "E"], "E": ["D", "F"], "F": ["E", "G"], "G": ["F"]
}
demand = {"A": 0.8, "B": 0.4, "C": 0.5, "D": 0.1, "E": 0.3, "F": 0.6, "G": 0.9}

V = {}
policy = {}
for s in zones:
    V[s] = 0.0
    policy[s] = "Stay"
gamma = 0.9

def get_val(s, a):
    if a == "Stay":
        r = demand[s] * 20.0 + (1.0 - demand[s]) * (-5.0)
        return r + gamma * V[s]
    else:
        return -1.0 + gamma * (0.7 * V[a] + 0.3 * V[s])

for _ in range(20):
    # 1. Policy Evaluation
    for _ in range(50):
        for s in zones:
            V[s] = get_val(s, policy[s])

    # 2. Policy Improvement
    for s in zones:
        valid_actions = ["Stay"] + neighbors[s]
        scores = []
        for a in valid_actions:
            scores.append(get_val(s, a))
        best_idx = np.argmax(scores)
        policy[s] = valid_actions[best_idx]

for s in zones:
    print("Zone:", s, "| Best Action:", policy[s], "| Value:", round(V[s], 2))