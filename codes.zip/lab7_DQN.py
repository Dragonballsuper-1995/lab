import gymnasium as gym
import torch
import torch.nn as nn
import numpy as np

env = gym.make("CartPole-v1")
net = nn.Sequential(nn.Linear(4, 32), nn.ReLU(), nn.Linear(32, 2))
opt = torch.optim.Adam(net.parameters(), lr=1e-3)
gamma = 0.99
eps = 0.2

for ep in range(1, 301):
    s, _ = env.reset()
    done = False
    total_r = 0.0

    while not done:
        s_t = torch.FloatTensor(s)
        if np.random.rand() < eps:
            a = env.action_space.sample()
        else:
            a = net(s_t).argmax().item()

        next_s, r, term, trunc, _ = env.step(a)
        done = term or trunc

        if done:
            next_q = 0.0
        else:
            next_q = net(torch.FloatTensor(next_s)).max().item()

        target = r + gamma * next_q
        loss = (net(s_t)[a] - target) ** 2

        opt.zero_grad()
        loss.backward()
        opt.step()

        s = next_s
        total_r += r

    eps = max(0.05, eps * 0.99)
    if ep % 50 == 0:
        print("DQN Episode:", ep, "| Score:", total_r)